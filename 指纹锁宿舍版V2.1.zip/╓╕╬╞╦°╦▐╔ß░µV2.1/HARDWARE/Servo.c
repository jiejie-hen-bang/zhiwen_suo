#include "stm32f10x.h"                  // Device header
#include "PWM.h"
#include "beep.h"
#include "delay.h"
#include "servo.h"
#include <stdbool.h>

bool Door_Flag = false;

void Servo_Init(void)
{
	PWM_Init();
}

void Servo_SetAngle(float Angle)
{
	PWM_SetCompare2(Angle / 180 * 2000 + 500);
}

void Servo_Wake(void)// �ߵ�ƽGPIO_SetBits(GPIOA, GPIO_Pin_7);���ѹ���
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_SetBits(GPIOA, GPIO_Pin_7);
	                                
}
void Servo_Sleep(void)// �͵�ƽGPIO_ResetBits(GPIOA, GPIO_Pin_7);�ص�����
{
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
	
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_ResetBits(GPIOA, GPIO_Pin_7);
}

void Open_Door(void)
{
	Door_Flag = false;//���ű�־��λ
	Buzzer_1();//��������ʾ����
	
		Servo_Wake();//����
	Servo_SetAngle(90);//���ŽǶ�
	Delay_ms(1000);
	Delay_ms(1000);
	Delay_ms(1000);
	Servo_SetAngle(0);//3s �� �Զ���λ
	
	Delay_ms(2000);Servo_Sleep();//����
}	
