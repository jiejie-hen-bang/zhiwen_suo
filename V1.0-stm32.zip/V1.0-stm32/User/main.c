#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "AD.h"
#include "beep.h"
#include "Servo.h"
#include "key.h"
#include "Serial.h"
#include "timer.h"
#include "as608.h"
#include "usart3.h"

uint8_t KeyNum;
uint8_t RxData;
uint16_t ADValue;
float Voltage;


float Angle;
uint16_t t = 0;


int main(void)
{
	OLED_Init();
	AD_Init();
	beep_init();
	Servo_Init();
	Key_Init();
	Serial_Init();
	OLED_ShowString(1, 1, "ADValue:");
	OLED_ShowString(2, 1, "Volatge:0.00V");
	
	
	Buzzer_3();//������ʾ
	while (1)
	{
		if(t++ / 100)
		{
			//��ص���3.7-4.2V
			ADValue = AD_GetValue();
			Voltage = (float)ADValue * 6.66 / 4095 ;	//0-4095���6.66��
			
			
			OLED_ShowNum(2, 9, Voltage, 1);
			OLED_ShowNum(2, 11, (uint16_t)(Voltage * 100) % 100, 2);
			
			KeyNum = Key_GetNum();
			if (KeyNum == 1)
			{
				Servo_Wake();//����
				Angle += 30;
				if (Angle > 180)
				{
					Angle = 0;
				}
			}
			Servo_SetAngle(Angle);
			
			OLED_ShowNum(3, 7, Angle, 3);
			
		}//Delay_s(5);Servo_Sleep();//����
		
		
		/*����ģ�鿪��*/
		if (Serial_GetRxFlag() == 1)
		 {
			 RxData = Serial_GetRxData();
			 Serial_SendByte(RxData);//�ѽ��յ�����һ�ֽ����ݻش�������
			 OLED_ShowHexNum(1,8,RxData,1);
			 switch(RxData)
			{
				case '1': Open_Door();
				break;
				default: break;
					
			}
		}
		/* *********************/ 
	
	
	
	
	}
}
