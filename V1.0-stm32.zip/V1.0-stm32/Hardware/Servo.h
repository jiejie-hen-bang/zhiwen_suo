#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init(void);
void Servo_SetAngle(float Angle);
void Servo_Wake(void);
void Servo_Sleep(void);
void Open_Door(void);
#endif
