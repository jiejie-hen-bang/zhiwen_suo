#include "beep.h"
#include "Delay.h"

void beep_init(void)
{
	
	GPIO_InitTypeDef GPIO_Initstruct;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	GPIO_Initstruct.GPIO_Pin= GPIO_Pin_4;
	GPIO_Initstruct.GPIO_Mode=GPIO_Mode_Out_PP;
	GPIO_Initstruct.GPIO_Speed=GPIO_Speed_2MHz;
	
	GPIO_Init(GPIOA,&GPIO_Initstruct);
	
}


void Buzzer_1(void)// OK
{
	
			B_OFF;
		Delay_ms(50);
		B_ON;
		Delay_ms(50);
		B_OFF;
		Delay_ms(50);
		B_ON;
		Delay_ms(70);
		
		B_OFF;
   
}
void Buzzer_2(void)// Warnning
{
	
			B_OFF;
		Delay_ms(70);
		B_ON;
		Delay_ms(70);
		B_OFF;
		Delay_ms(70);
		B_ON;
		Delay_ms(700);
		B_OFF;
	Delay_ms(70);
		B_ON;
		Delay_ms(70);
		B_OFF;
		Delay_ms(70);
		B_ON;
		Delay_ms(700);
		B_OFF;
	Delay_ms(70);
		B_ON;
		Delay_ms(70);
		B_OFF;
		Delay_ms(70);
		B_ON;
		Delay_ms(700);
		B_OFF;
		
   
}
void Buzzer_3(void)// Start
{
	
			B_OFF;
		Delay_ms(50);
		B_ON;
		Delay_ms(80);
		B_OFF;
		Delay_ms(50);
		B_ON;
		Delay_ms(80);
		B_OFF;
		Delay_ms(50);
		B_ON;
		Delay_ms(80);
		B_OFF;
   
}
void Buzzer_4(void)// ding
{	
			B_OFF;
		Delay_ms(50);
		B_ON;
		Delay_ms(100);
		B_OFF;

}
void Buzzer_5(void)// Finish
{	
			
		Delay_ms(50);
		B_ON;
		Delay_ms(500);
		B_OFF;
	Delay_ms(50);
		B_ON;
	Delay_ms(50);B_OFF;
}
